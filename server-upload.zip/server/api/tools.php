<?php
/**
 * Tools API Endpoint - PHP 7.0+ Compatible (no arrow functions)
 *
 * GET    /tools.php           - List all tools
 * GET    /tools.php?id=xxx    - Get single tool
 * POST   /tools.php           - Create new tool (auth required)
 * PUT    /tools.php?id=xxx    - Update tool (auth required)
 * DELETE /tools.php?id=xxx    - Delete tool (auth required)
 */

require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? $_GET['id'] : null;

// Helper: normalize boolean values from JSON
function normalizeBool($val) {
    if (is_bool($val)) return $val;
    if (is_int($val)) return $val !== 0;
    if (is_string($val)) return strtolower($val) === 'true' || $val === '1';
    return false;
}

// Load data with error handling
function loadTools() {
    global $CONFIG;
    $file = $CONFIG['tools_file'];

    if (!file_exists($file)) {
        $altFile = dirname(__DIR__) . '/data/tools.json';
        if (file_exists($altFile)) {
            $file = $altFile;
        } else {
            error_log('TOOLS: File not found: ' . $file);
            return [];
        }
    }

    $content = @file_get_contents($file);
    if ($content === false) {
        error_log('TOOLS: Cannot read file: ' . $file);
        return [];
    }

    $data = json_decode($content, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('TOOLS: JSON decode error: ' . json_last_error_msg());
        return [];
    }

    if (!is_array($data) || !isset($data['tools'])) {
        error_log('TOOLS: Invalid structure');
        return [];
    }

    $tools = $data['tools'];
    error_log('TOOLS: Loaded ' . count($tools) . ' tools from ' . $file);

    foreach ($tools as $key => &$tool) {
        $tool['is_internal'] = normalizeBool($tool['is_internal']);
    }
    unset($tool);

    return $tools;
}

// Save data
function saveTools($tools) {
    global $CONFIG;
    $content = json_encode(array('tools' => $tools), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($CONFIG['tools_file'], $content) !== false;
}

// Generate UUID v4
function generateUUID() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

// Helper: sort by is_internal then display_order
function sortTools($a, $b) {
    $aInternal = normalizeBool($a['is_internal'] ?? false);
    $bInternal = normalizeBool($b['is_internal'] ?? false);
    if ($aInternal !== $bInternal) {
        return $aInternal ? 1 : -1;
    }
    $aOrder = isset($a['display_order']) ? (int)$a['display_order'] : 0;
    $bOrder = isset($b['display_order']) ? (int)$b['display_order'] : 0;
    return $aOrder - $bOrder;
}

switch ($method) {
    case 'GET':
        $tools = loadTools();

        if ($id) {
            $found = null;
            foreach ($tools as $tool) {
                if ($tool['id'] === $id) {
                    $found = $tool;
                    break;
                }
            }
            if (!$found) {
                jsonError('Tool not found', 404);
            }
            jsonResponse(array('success' => true, 'tool' => $found));
        } else {
            usort($tools, 'sortTools');
            jsonResponse(array('success' => true, 'tools' => $tools));
        }
        break;

    case 'POST':
        requireAuth();
        $body = getJsonBody();

        if (empty($body['title']) || empty($body['link'])) {
            jsonError('Title and link are required', 400);
        }

        $tools = loadTools();

        $bodyInternal = normalizeBool($body['is_internal'] ?? false);
        $maxOrder = 0;
        foreach ($tools as $t) {
            if (normalizeBool($t['is_internal'] ?? false) === $bodyInternal) {
                $order = isset($t['display_order']) ? (int)$t['display_order'] : 0;
                if ($order > $maxOrder) {
                    $maxOrder = $order;
                }
            }
        }

        $newTool = array(
            'id' => generateUUID(),
            'title' => $body['title'],
            'description' => isset($body['description']) ? $body['description'] : '',
            'link' => $body['link'],
            'icon' => isset($body['icon']) ? $body['icon'] : 'Music2',
            'is_internal' => $bodyInternal,
            'display_order' => $maxOrder + 1,
            'created_at' => date('c'),
            'updated_at' => date('c'),
        );

        $tools[] = $newTool;

        if (!saveTools($tools)) {
            jsonError('Failed to save tool', 500);
        }

        jsonResponse(array('success' => true, 'tool' => $newTool), 201);
        break;

    case 'PUT':
        requireAuth();

        if (!$id) {
            jsonError('Tool ID is required', 400);
        }

        $body = getJsonBody();
        $tools = loadTools();

        $found = false;
        foreach ($tools as $key => &$tool) {
            if ($tool['id'] === $id) {
                if (isset($body['title'])) $tool['title'] = $body['title'];
                if (isset($body['description'])) $tool['description'] = $body['description'];
                if (isset($body['link'])) $tool['link'] = $body['link'];
                if (isset($body['icon'])) $tool['icon'] = $body['icon'];
                if (isset($body['is_internal'])) $tool['is_internal'] = normalizeBool($body['is_internal']);
                if (isset($body['display_order'])) $tool['display_order'] = (int)$body['display_order'];
                $tool['updated_at'] = date('c');
                $found = true;
                break;
            }
        }
        unset($tool);

        if (!$found) {
            jsonError('Tool not found', 404);
        }

        if (!saveTools($tools)) {
            jsonError('Failed to save tool', 500);
        }

        jsonResponse(array('success' => true, 'message' => 'Tool updated'));
        break;

    case 'DELETE':
        requireAuth();

        if (!$id) {
            jsonError('Tool ID is required', 400);
        }

        $tools = loadTools();
        $originalCount = count($tools);
        $deletedTool = null;

        foreach ($tools as $tool) {
            if ($tool['id'] === $id) {
                $deletedTool = $tool;
                break;
            }
        }

        $filtered = array();
        foreach ($tools as $tool) {
            if ($tool['id'] !== $id) {
                $filtered[] = $tool;
            }
        }
        $tools = $filtered;

        if (count($tools) === $originalCount) {
            jsonError('Tool not found', 404);
        }

        // Reorder remaining tools in the same category
        $category = normalizeBool($deletedTool['is_internal'] ?? false);
        $categoryTools = array();
        foreach ($tools as $tool) {
            if (normalizeBool($tool['is_internal'] ?? false) === $category) {
                $categoryTools[] = $tool;
            }
        }

        usort($categoryTools, 'sortTools');

        $orderMap = array();
        foreach ($categoryTools as $index => $tool) {
            $orderMap[$tool['id']] = $index + 1;
        }

        foreach ($tools as $key => &$tool) {
            if (normalizeBool($tool['is_internal'] ?? false) === $category && isset($orderMap[$tool['id']])) {
                $tool['display_order'] = $orderMap[$tool['id']];
            }
        }
        unset($tool);

        if (!saveTools($tools)) {
            jsonError('Failed to save tool', 500);
        }

        jsonResponse(array('success' => true, 'message' => 'Tool deleted'));
        break;

    default:
        jsonError('Method not allowed', 405);
}
